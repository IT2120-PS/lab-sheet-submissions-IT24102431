setwd("C:\\Users\\USER\\Desktop\\IT24102431")

#Q1
n <- 50        # number of students
p <- 0.85      # probability of passing

# i) Distribution of X
cat("X ~ Binomial(n=50, p=0.85)\n")

# ii) Probability that at least 47 students passed
prob_atleast47 <- pbinom(46, size = n, prob = p, lower.tail = FALSE)
cat("P(X >= 47) =", prob_atleast47, "\n")

#Q2
lambda <- 12   # average calls per hour

# i) Random variable
cat("X = number of calls per hour\n")

# ii) Distribution
cat("X ~ Poisson(lambda=12)\n")

# iii) Probability of exactly 15 calls
prob_15 <- dpois(15, lambda = lambda)
cat("P(X = 15) =", prob_15, "\n")