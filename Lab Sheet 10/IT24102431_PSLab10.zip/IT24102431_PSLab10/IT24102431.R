setwd("C:\\Users\\USER\\Desktop\\IT24102431_PSLab10")

# (ii)
# Observed frequencies
observed <- c(120, 95, 85, 100)

# Expected frequencies (equal probability)
expected <- rep(sum(observed) / 4, 4)

# Chi-squared goodness of fit test
test_result <- chisq.test(observed, p = c(0.25, 0.25, 0.25, 0.25))

# Print result
test_result
