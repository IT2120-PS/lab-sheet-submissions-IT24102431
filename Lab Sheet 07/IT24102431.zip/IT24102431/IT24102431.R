setwd('C:\\Users\\USER\\Desktop\\IT24102431')

#Q1
a <- 0     # lower bound
b <- 40    # upper bound
p_uniform <- (25 - 10) / (b - a)
cat("\nQ1: Probability train arrives between 8:10 and 8:25 =", p_uniform, "\n")

#Q2
# λ = 1/3
lambda <- 1/3
# Probability update takes at most 2 hours
p_exp <- pexp(2, rate = lambda)
cat("\nQ2: Probability update ≤ 2 hours =", p_exp, "\n")

#Q3
mean_iq <- 100
sd_iq <- 15

#(i)
p_norm1 <- 1 - pnorm(130, mean = mean_iq, sd = sd_iq)
cat("\nQ3(i): Probability IQ > 130 =", p_norm1, "\n")

#(ii)
iq_95 <- qnorm(0.95, mean = mean_iq, sd = sd_iq)
cat("\nQ3(ii): 95th percentile IQ =", iq_95, "\n")
